 package com.letsstartcoding.springbootrestapiexample.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letsstartcoding.springbootrestapiexample.model.Employee;
import com.letsstartcoding.springbootrestapiexample.repository.EmployeeRepository;


@Service
public class EmployeeDAO {
	
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	//save
	
	public Employee save(Employee emp){
		
		return employeeRepository.save(emp);
	}
	
	
	//search
	
	public List<Employee> findAll(){
		
		return employeeRepository.findAll();
		
	}
	//update
	
	public Employee findOne(Long empid){
		return employeeRepository.findOne(empid);
		
		}
	//delete
	
	public void delete(Employee emp){
		employeeRepository.delete(emp);
	}

}
